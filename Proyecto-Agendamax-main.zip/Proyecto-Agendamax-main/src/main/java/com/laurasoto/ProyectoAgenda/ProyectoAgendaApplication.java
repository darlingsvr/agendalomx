package com.laurasoto.ProyectoAgenda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoAgendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoAgendaApplication.class, args);
	}

}
