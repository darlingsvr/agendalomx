package com.laurasoto.ProyectoAgenda.repositorios;



import com.laurasoto.ProyectoAgenda.modelos.Region;

public interface RegionRepositorio extends BaseRepositorio<Region> {
    
}
